# Extensive Grid Search CV Params Search with SVC
* Using features ranked with TuRF
* Feature space contains original audio + voice audio + accompainment audio
* tested extensive grid with 4 kernels (linear, poly, rbf, sigmoid) and params (check script)
* Computed best parameters for top10, 25, 50, 100, 200, 300, 400, 500, 600, 700, 800
