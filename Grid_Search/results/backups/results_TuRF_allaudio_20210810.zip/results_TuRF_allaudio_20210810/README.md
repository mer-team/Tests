Feature Ranking Tests:
* Using TuRF + ReliefF
* tested top features 1 to 100 and then top100 to max (10 feats interval, 100, 110, 120)
* GridSearchCV with SVC and RBF (cost 1, 10 100, gamma 1 and 0.1
* Stopped at 860 feats (taking too much time / cores))
